package com.cg.entities;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;




@Entity
@Table(name="Timesheet")
public class Timesheet implements Serializable
{

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="timesheet_Id")

	private int timesheet_Id;

	@NotEmpty(message="Name is mandatory")
	@Size(max=8)
	@Pattern(regexp="^[A-Z][0-9]{3,8}&",message="Enter Valid Pattern")
	@Column(name="emp_id")
	private String emp_Id;
	
	@Column(name="timesheet_Date")
	private Date timesheet_Date;	
	private String hour1;	
	private String hour2;
	private String hour3;
	private String hour4;
	private String hour5;
	private String hour6;
	private String hour7;
	private String hour8;
	
	public int getTimesheet_Id() {
		return timesheet_Id;
	}
	public void setTimesheet_Id(int timesheet_Id) {
		this.timesheet_Id = timesheet_Id;
	}
	public String getEmp_Id() {
		return emp_Id;
	}
	public void setEmp_Id(String emp_Id) {
		this.emp_Id = emp_Id;
	}
	public Date getTimesheet_Date() {
		return timesheet_Date;
	}
	public void setTimesheet_Date(Date timesheet_Date) {
		this.timesheet_Date = timesheet_Date;
	}
	public String getHour1() {
		return hour1;
	}
	public void setHour1(String hour1) {
		this.hour1 = hour1;
	}
	public String getHour2() {
		return hour2;
	}
	public void setHour2(String hour2) {
		this.hour2 = hour2;
	}
	public String getHour3() {
		return hour3;
	}
	public void setHour3(String hour3) {
		this.hour3 = hour3;
	}
	public String getHour4() {
		return hour4;
	}
	public void setHour4(String hour4) {
		this.hour4 = hour4;
	}
	public String getHour5() {
		return hour5;
	}
	public void setHour5(String hour5) {
		this.hour5 = hour5;
	}
	public String getHour6() {
		return hour6;
	}
	public void setHour6(String hour6) {
		this.hour6 = hour6;
	}
	public String getHour7() {
		return hour7;
	}
	public void setHour7(String hour7) {
		this.hour7 = hour7;
	}
	public String getHour8() {
		return hour8;
	}
	public void setHour8(String hour8) {
		this.hour8 = hour8;
	}
	public Timesheet() {
		super();
	} 
	
	
}