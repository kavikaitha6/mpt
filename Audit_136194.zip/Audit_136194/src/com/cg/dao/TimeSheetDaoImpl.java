package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.entities.Timesheet;

@Repository
@Transactional
public class TimeSheetDaoImpl implements TimeSheetDao {

	//Below annotation is required to inject auto created entityManager from entityManagerFactory
	@PersistenceContext
	private EntityManager entityManager;

	//save data into database
	@Override
	public Timesheet save(Timesheet trainee) {

		entityManager.persist(trainee); //inserts 
		entityManager.flush();	//required to reflect changes on database
		
		return trainee;
	}
	
	//display list
	@Override
	public List<Timesheet> get(int id) 
	{
		TypedQuery<Timesheet> query = entityManager.createQuery("SELECT e FROM Timesheet e WHERE e.emp_Id="+id, Timesheet.class);
		return query.getResultList();
	}
	


	
}