package com.cg.dao;

import java.util.List;

import com.cg.entities.Timesheet;

public interface TimeSheetDao {

	public  Timesheet save(Timesheet trainee);

	public List<Timesheet> get(String id);

	


}