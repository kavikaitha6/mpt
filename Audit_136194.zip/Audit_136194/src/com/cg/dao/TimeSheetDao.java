package com.cg.dao;

import java.util.List;

import com.cg.entities.Timesheet;

public interface TimeSheetDao {

	public abstract Timesheet save(Timesheet trainee);
	
	public abstract List<Timesheet> get(int id);

	


}