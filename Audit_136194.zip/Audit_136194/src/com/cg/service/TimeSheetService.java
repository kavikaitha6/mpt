package com.cg.service;

import java.util.List;

import com.cg.entities.Timesheet;

public interface TimeSheetService {

	public  Timesheet save(Timesheet employee);

	public List<Timesheet> getTrainee(String emp_Id);



}