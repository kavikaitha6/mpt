package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.TimeSheetDao;
import com.cg.entities.Timesheet;

@Service
public class TimeSheetServiceImpl implements TimeSheetService {

	@Autowired
	private TimeSheetDao traineeDaoImpl;
	
	@Override
	public Timesheet save(Timesheet trainee) {
		return traineeDaoImpl.save(trainee);
	}
	
	
	@Override
	public List<Timesheet> getTrainee(int id) {
		return traineeDaoImpl.get(id);
	}


	
}