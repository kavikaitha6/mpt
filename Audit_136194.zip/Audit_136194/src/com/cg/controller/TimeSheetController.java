package com.cg.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.Timesheet;
import com.cg.service.TimeSheetService;

@Controller
public class TimeSheetController {

	@Autowired
	private TimeSheetService traineeService;

	@RequestMapping("/add.htm")
	public String addTrainee(Model map) 
	{
		map.addAttribute("trainee", new Timesheet());
		map.addAttribute("domainList", new String[] { "DATA_ENTRY",
				"ACCOUNTS_TALLY", "LEDGER_POSTINGS", "BALANCE_SHEET",
				"RETURNS_FILING" });
		return "add";
	}

	@RequestMapping(value = "/save.htm", method = RequestMethod.POST)
	public String saveTrainee(@ModelAttribute("trainee")  Timesheet trainee, Model model) {
		trainee = traineeService.save(trainee);
		model.addAttribute("message", "Trainee with id  added successfully!");
		return "success";
	}

	@RequestMapping("/list.htm")
	public String displDetails() 
	{
		return "list";
	}

	@RequestMapping(value = "/get.htm")
	public String getTrainee(@RequestParam("emp_Id") int emp_Id, Model model)
	{
		List<Timesheet> trainees = traineeService.getTrainee(emp_Id);
		model.addAttribute("traineeList", trainees);
		return "list";
	}

	@RequestMapping("/home.htm")
	public String home()
	{
		String redirect="../../login";
		return redirect;
	}

}